using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[RequireComponent(typeof(Weapon))]
public class Player : MonoBehaviour
{
    [SerializeField] private Weapon weapon;


    private void Start()
    {
        weapon = GetComponent<Weapon>();
        Debug.Log("�������� �Ϸ�");
    }

}
