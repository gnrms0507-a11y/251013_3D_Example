using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] private int _maxHp ;

    private int _currnetHp; //����
    [SerializeField] Transform targetPlayer; //�÷��̾� (Ÿ��) ����
    private float moveSpeed = 2.0f;

    private void Awake()
    {
        Init();
        transform.LookAt(targetPlayer);
    }
    private void Init()
    {
        _currnetHp = _maxHp; //���� �ʱ�ȭ
    }


    //�÷��̾� �Ѿ˿� �¾�����
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "PlayerBullet")
        {
            TakeDamage();
        }
    }
    private void TakeDamage()
    {
        _currnetHp--;
        Debug.Log("���� ü��1����");
        if (_currnetHp <= 0)
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        MoveObj();
    }
    private void MoveObj()
    {
        gameObject.transform.position = 
            Vector3.MoveTowards(gameObject.transform.position, targetPlayer.transform.position, moveSpeed * Time.deltaTime);
    }
}
